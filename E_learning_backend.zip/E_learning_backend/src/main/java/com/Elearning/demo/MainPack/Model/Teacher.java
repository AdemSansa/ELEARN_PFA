package com.Elearning.demo.MainPack.Model;

public class Teacher extends User{
}
