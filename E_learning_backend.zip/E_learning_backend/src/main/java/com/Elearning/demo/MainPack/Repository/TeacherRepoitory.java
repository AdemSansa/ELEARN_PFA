package com.Elearning.demo.MainPack.Repository;

public interface TeacherRepoitory {
}
