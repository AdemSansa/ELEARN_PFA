package com.Elearning.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
